#include "../includes/header.h"

void	m_echo(char **s)
{
	int	i;
	int	nl;

	i = 0;
	nl = 0;
	if (!(*s))
		ft_putchar_fd('\n', 1);
	else
	{
		if (!ft_nstrncmp(s[i], "-n", 3))
		{
			nl = 1;
			i++;
		}
		while (s[i] != NULL)
		{
			ft_putstr_fd(s[i], 1);
			if (s[i + 1] != NULL)
				ft_putchar_fd(' ', 1);
			i++;
		}
		if (!nl)
			ft_putchar_fd('\n', 1);
	}
}

void	m_cd(const char *dirr)
{
	if (!dirr)
	{
		if (!getenv("HOME"))
		{
			printf("Environment not found\n");
			return ;
		}
		chdir(getenv("HOME"));
		return ;
	}
	if (!chdir(dirr))
		return ;
	printf("%s : is not directory\n", dirr);
}

void	m_pwd(void)
{
	char	path [1024];

	if (getcwd(path, sizeof(path)) == NULL)
		return ;
	ft_putstr_fd(getcwd(path, sizeof(path)), 1);
	ft_putchar_fd('\n', 1);
}

void	m_exit(char **str)
{
	ft_putstr_fd("exit ", STDERR);
	if (!str[1])
    {
        ft_putendl_fd("💚", STDERR);
        exit(0);
    }
	if (str[1] && str[2])
	{
		ft_putendl_fd("minishell: exit: too many arguments", STDERR);
        exit(0);
	}
	else if (str[1] && !ft_checkdigit(str[1]))
	{
		ft_putstr_fd("minishell: exit: ", STDERR);
		ft_putstr_fd(str[1], STDERR);
		ft_putendl_fd(": numeric argument required", STDERR);
		g_b.exit_status = 255;
        exit(255);
	}
	else
    {
        ft_putstr_fd(str[1], STDERR);
		g_b.exit_status = ft_atoi(str[1]);
        exit(ft_atoi(str[1]));
    }
}

int	ft_checkdigit(char *str)
{
	int	i;

	i = 0;
	if (str[0] == '-')
		i = 1;
	while (str[i])
	{
		if (!ft_isdigit(str[i]) || i >= 19)
			return (0);
		i++;
	}
	return (1);
}

void	m_display_env(t_env *list)
{
	if (!list)
		return ;
	while (list)
	{
		printf("%s=\"%s""\"\n", list->var, list->value);
		list = list->next;
	}
}

void	m_export(t_env	**envt, char **str)
{
	int		i;
	char	*newvar;
	char	*check;

	i = -1;
	if (exp_hash(*str, *envt))
		return ;
	while (str[++i])
	{	
		newvar = varexport(str[i], '=');
		check = ft_search(str[i], '=');
		if (!check)
		{
			free(newvar);
			return ;
		}
		if (!c_syntax(newvar))
		{
			free(newvar);
			return ;
		}
		if (!check_dup(envt, str[i]))
			ft_zid_back(envt, ft_lstne(newvar, check));
		free(newvar);
	}
}

void	m_unset(char **str, t_env	**envt)
{
	int i;

	i = 0;
	if (!str[i])
	{
		printf("unset: not enough arguments\n");
		return ;
	}
	while(str[i])
	{
		unsetvar(str[i], envt);
		i++;
	}
}

void	unsetvar(char *str, t_env **envt)
{
	t_env *head;
	t_env *prev;
	int i = 0;
	head = *envt;
    while (head)
    {
        if (!ft_nstrncmp(str, head->var, ft_strlen(str) + 1))
        {
            if (i == 0)
            {
                *envt = head->next;
				if(!head->value)
					head->value = ft_strdup("");
                return ;
            }
            prev->next = head->next;
			if(!head->value)
				head->value = ft_strdup("");
            return ;
        }
        prev = head;
        head = head->next;
        i++;
    }
}
