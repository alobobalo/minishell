#include "../includes/header.h"

int	exp_hash(char *str, t_env *tenv)
{
	if (!(str) || *str == '#')
	{
		export_o(tenv);
		return (1);
	}
	return (0);
}

void	export_o(t_env	*env)
{
	while (env)
	{
		printf("declare -x %s=\"%s""\"\n", env->var, env->value);
		env = env->next;
	}
}

int	check_dup(t_env	**tenv, char *s)
{
	t_env	*root;
	char	*str;

	root = *tenv;
	str = varexport(s, '=');
	while (root && ft_nstrncmp(root->var, str, ft_strlen(str)))
	{
		root = root->next;
	}
	if (root)
	{
		root->value = ft_search(s, '=');
		free(str);
		return (1);
	}
	free(str);
	return (0);
}

char	*ft_search(char *s, char c)
{
	int		i;

	i = 0;
	if (!s)
		return (NULL);
	while (s[i])
	{
		if (s[i] == c)
		{
			i++;
			return (s + i);
		}
		i++;
	}
	return (ft_strdup(""));
}

void	ft_zid_back(t_env **lst, t_env *ne)
{
	t_env	*l1;

	l1 = *lst;
	if (!lst)
		*lst = ne;
	if (lst != NULL)
	{
		if (*lst == NULL)
			*lst = ne;
		else
		{
			while (l1->next != NULL)
				l1 = l1->next;
			l1->next = ne;
		}
	}
}

int	c_syntax(char *var)
{
	int	i;

	i = 0;
	while (var[i])
	{
		if (var[i] == '(' || var[i] == ')' || (var[0] >= 0 && var[0] < 9))
		{
			ft_putstr_fd("not an identifier : ", 2);
			ft_putchar_fd(var[i], 2);
			return (0);
		}
		i++;
	}
	return (1);
}

t_env	*ft_lstne(char *var, char *value)
{
	t_env	*htr;

	htr = malloc(sizeof(t_env));
	if (!htr)
		return (NULL);
	htr->var = ft_strdup(var);
	htr->value = ft_strdup(value);
	htr->next = NULL;
	return (htr);
}

char *varexport(char *str, char c)
{
	int i;
	char *var;

	i = 0;
	var = ft_malloc(sizeof(char) * sublen_str(str, c) + 1);
	while (str[i] && str[i] != c)
	{
		var[i] = str[i];
		i++;
	}
	var[i] = '\0';
	return (var);
}

int	sublen_str(char *str, char c)
{
	int	i;

	i = 0;
	while (str[i] != c && str[i])
		i++;
	return (i);
}


size_t			size_env(t_env *lst)
{
	size_t	lst_len;

	lst_len = 0;
	while (lst && lst->next != NULL)
	{
		if (lst->value != NULL)
		{
			lst_len += ft_strlen(lst->value);
			lst_len++;
		}
		lst = lst->next;
	}
	return (lst_len);
}