#include "../includes/header.h"

int    g_status;

void	ctrl_handler(int sig)
{
	sig = 1;
	exit(1);
}

void	sig_handl(int sig)
{
	(void)sig;
	rl_replace_line("", 0);
	rl_on_new_line();
	write(1, "Quit: 3", 7);
	write(1, "\n", 1);
}

void	sig_handle(int sig)
{
	(void)sig;
	rl_replace_line("", 0);
	rl_on_new_line();
	write(1, "\n", 1);
	rl_redisplay();
}

void	exit_handle(int exits)
{
	ft_putendl_fd("exit", 1);
	exit(exits);
}

void	signals(void)
{
	if (signal(SIGINT, SIG_IGN) == SIG_ERR)
		exit(1);
	if (signal(SIGQUIT, sig_handl) == SIG_ERR)
		exit(1);
}

void	signals2(void)
{
	if (signal(SIGINT, sig_handle) == SIG_ERR)
		exit(1);
	if (signal(SIGQUIT, SIG_IGN) == SIG_ERR)
		exit(1);
}

void	heredoc_signal(void)
{
	if (signal(SIGINT, ctrl_handler) == SIG_ERR)
		exit(1);
	if (signal(SIGQUIT, SIG_IGN) == SIG_ERR)
		exit(1);
}

void	signals3(void)
{
	signal(SIGINT, SIG_IGN);
	signal(SIGQUIT, SIG_IGN);
}

void	signals4(void)
{
	signal(SIGINT, SIG_DFL);
	signal(SIGQUIT, SIG_DFL);
}

static	int	ft_countlen(int n)
{
	int	i;

	i = 0;
	if (n < 0)
	{
		n = n * -1;
		i++;
	}
	while (n != 0)
	{
		n = (n / 10);
		i++;
	}
	return (i);
}

char	*ft_itoa(int n)
{
	int		len;
	long	nbr;
	char	*ptr;

	nbr = n;
	if (nbr == 0)
		return (ft_strdup("0"));
	len = ft_countlen(nbr);
	ptr = malloc(sizeof(char) * len + 1);
	if (!ptr)
		return (0);
	if (nbr < 0)
	{
		nbr = nbr * (-1);
		ptr[0] = '-';
	}
	ptr[len--] = '\0';
	while (nbr != 0)
	{
		ptr[len--] = (nbr % 10) + '0';
		nbr = nbr / 10;
	}
	return (ptr);
}