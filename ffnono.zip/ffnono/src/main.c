/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mabdenna <mabdenna@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/03 02:58:00 by zanejar           #+#    #+#             */
/*   Updated: 2023/03/09 06:17:14 by mabdenna         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/header.h"

void m_execution(t_cmd_list *list, t_env **env)
{
	if (!list->next)
    {
        if (is_builtin(list) != 0 && typelookup(list) == 0)
            exebultin(list, env);
        else
            execute_commands_with_pipes(list, env);
    }
    else
        execute_commands_with_pipes(list, env);
}

int countPipes(t_cmd_list *list)
{
    int i = 1;
    while(list)
    {
        i++;
        list = list->next;
    }
    return(i);
}
void fttobi(t_cmd_list *cc)
{
    t_cmd_list *tmp = cc;
    while (tmp->token)
    {
        if (tmp->token->e_type == TOKEN_DLREDIRECT)
        {
        cc->in = heredoc(tmp->token->next->value);
            if (tmp->token->next->next)
                tmp->token = tmp->token->next;
        }
        if (!tmp->token->next->next)
            return;
        tmp->token = tmp->token->next;
    }
}

int  typelookup(t_cmd_list *cmde)
{
    t_cmd_list *cmdd;
    int i;

    i = 0;
    cmdd = cmde;
    while (cmdd)
    {
        while(cmdd->token)
        {
            if (cmdd->token->e_type == TOKEN_DLREDIRECT)
                return (1);
            else if (cmdd->token->e_type == TOKEN_DRREDIRECT)
                i = 2;
            else if (cmdd->token->e_type == TOKEN_LREDIRECT)
                i = 3;
            else if (cmdd->token->e_type == TOKEN_RREDIRECT)
                i = 4;
            cmdd->token = cmdd->token->next;
        }
        cmdd = cmdd->next;
    }
    return(i);
}


int llo(t_cmd_list *llo)
{
    int i = 0;
    while(llo->token)
    {
        if (llo->token->e_type == TOKEN_DRREDIRECT)
            i = 2;
        else if (llo->token->e_type == TOKEN_LREDIRECT)
            i = 3;
        else if (llo->token->e_type == TOKEN_RREDIRECT)
            i = 4;
        llo->token = llo->token->next;
    }
    return (i);
}
char *valuehredoclookup(t_cmd_list *cmdp)
{
    t_cmd_list *tmp;

    tmp = cmdp;
    while(tmp->token)
    {
        if (tmp->token->e_type == TOKEN_DLREDIRECT)
            return (ft_strdup(tmp->token->next->value));
        tmp->token = tmp->token->next;
    }
    return(NULL);
}

char *valuelookup(t_cmd_list *cmdp)
{
    t_cmd_list *tmp;

    tmp = cmdp;
    while(tmp->token)
    {
        if (tmp->token->e_type == TOKEN_DRREDIRECT)
            return (ft_strdup(tmp->token->next->value));
        else if (tmp->token->e_type == TOKEN_RREDIRECT)
            return (ft_strdup(tmp->token->next->value));
        tmp->token = tmp->token->next;
    }
    return(NULL);
}

char **patharrays(t_env *env, int a)
{
	char *ptr;
    char *exe;
    char **sp;
	char **shit;

	ptr = env_to_str(env);
	sp = ft_split(ptr, '\n');
	exe = ft_strdup(find_path(env));
	if (!exe)
		return (0);
	if (a == 1)
		return (sp);
	shit = ft_split(exe, ':');
	return (shit);
}

void handle_pipe(t_cmd_list *cmd_list, int pipefds[], int j)
{
    if(cmd_list->next)
    {
        if(dup2(pipefds[j + 1], 1) < STDOUT_FILENO)
        {
            perror("dup2");
            exit(EXIT_FAILURE);
        }
    }
    if(j != 0 )
    {
        if(dup2(pipefds[j-2], 0) < STDIN_FILENO)
        {
            perror(" dup2");
            exit(EXIT_FAILURE);
        }
    }
}
void close_unused_pipes(int pipefds[], int numPipes)
{
    int i = 0;
    while (i < 2 * numPipes)
    {
        close(pipefds[i]);
        i++;
    }
}

void ft_hardcoding(char *e, char **m)
{
    char *args[] = {"cat", "/tmp/.ee.txt", NULL};
    if(execve(e, &args[0], m) < 0)
        exit(error_message(e));
    if (unlink("/tmp/.ee.txt") == -1)
    {
        perror("/tmp/.ee.txt");
    }
    exit(1);
}

int ft_exeher(t_cmd_list *b)
{
    t_cmd_list *tm;
    tm = b;
    while (tm)
    {
        if (typelookup(tm) == 1 && !tm->next)
        {
            if (ft_nstrncmp(tm->cdm_line[0], "cat", 3) == 0)
                return (1);
        }
        tm = tm->next;
    }
    return (0);
}



int children(t_cmd_list *comanda, t_env **envir)
{
    if (!comanda->cdm_line[0])
        exit(1);
    if ((ft_strcmp(comanda->cdm_line[0], "cat") == 0) && (typelookup(comanda) == 1))
        exit(1);
    if (comanda->in)
        dup2(comanda->in, STDIN_FILENO);
    if (comanda->out != 1)
        dup2(comanda->out, STDOUT_FILENO);
    if (typelookup(comanda) != 0)
    {
        if (is_builtin(comanda) != 0)
            exit(1);
        else if (typelookup(comanda) == 1)
            exit(1);
    }
    else if(execve(path_exec(patharrays(*envir, 0), comanda->cdm_line[0]), &comanda->cdm_line[0], patharrays(*envir, 1)) < 0)
    {
        g_b.exit_status = error_message(path_exec(patharrays(*envir, 0), comanda->cdm_line[0]));
        exit(127);
    }
    return (g_b.exit_status);
}

void    ft_hardcodetb(t_cmd_list *tn, t_env **env)
{
    char **str;
    int i;
    int j;

    j = 0;
    i = 0;
    while (tn->cdm_line[i] != NULL)
        i++;
    str = ft_malloc(sizeof(char *) * (i +1));
    i--;
    while(j < i)
    {
        str[j] = ft_strdup(tn->cdm_line[j]);
        j++;
    }
    str[j] = valuelookup(tn);
    str[++j] = 0;
    if(execve(path_exec(patharrays(*env, 0), tn->cdm_line[0]), &str[0], patharrays(*env, 1)) < 0)
    {
        g_b.exit_status = error_message(path_exec(patharrays(*env, 0), tn->cdm_line[0]));
        exit(1);
    }
}

int    pipehere(t_cmd_list *op, int *fdh)
{
    while (op)
    {
            if (!op->next && typelookup(op) != 1)
                return (0);
        while (op->token)
        {
            if (op->token->e_type == TOKEN_DLREDIRECT)
            {
*fdh = open("/tmp/.ee.txt", O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
                if (*fdh == -1)
                    perror("open");
                herdocprompt(*fdh, op->token->next->value);
                close(*fdh);
                if (op->token->next->next)
                    op->token = op->token->next;
            }
            if (!op->token->next->next)
                break;
            op->token = op->token->next;
        }
        if (!op->next && ft_exeher(op) == 1)
            return(1);
        op = op->next;
    }
    return(0);
}

int ft_lencmd(char **ss)
{
    int i = 0;
    while (ss[i] != NULL)
    {
        i++;
    }
    return (i);
}

char *ftpiperr(t_cmd_list *oo)
{
    t_cmd_list *tmp;
    tmp = oo;
    while (tmp && tmp->next)
    {
        tmp = tmp->next;
    }
    if (!tmp->cdm_line[0])
        return(NULL);
    else
        return (tmp->cdm_line[0]);
    return (NULL);
}

void    herdocchild(t_cmd_list *lli, t_env **eo)
{
    t_cmd_list *ll;
    char *ar;
    int tmp_fd;

    ll = lli;
    signals4();
    ar = ftpiperr(ll);
    if (pipehere(ll, &tmp_fd) == 1 && ar != NULL)
    {
        ft_hardcoding(path_exec(patharrays(*eo, 0), ar), patharrays(*eo, 1));
        exit(1);
    }
    else if (ft_strcmp(ar, "cat") == 0)
        exit(1);
    else if (is_builtin(lli) == 1)
    {
        exebultin(lli, eo);
        exit(1);
    }
    else if(execve(path_exec(patharrays(*eo, 0), ll->cdm_line[0]), &ll->cdm_line[0], patharrays(*eo, 1)) < 0)
    {
        g_b.exit_status = error_message(path_exec(patharrays(*eo, 0), ll->cdm_line[0]));
        exit(1);
    }     
}

int  checkforher(t_cmd_list *lli, t_env **eo)
{
    t_cmd_list *tor;
    pid_t pid;
    int status;

    tor = lli;
    if (typelookup(lli) == 1)
    {
        pid = fork();
        if (pid == 0)
            herdocchild(tor, eo);
        waitpid(pid, &status, 0);
	   	if (WIFEXITED(status))
		    g_b.exit_status = WEXITSTATUS(status);
    }
    else if (llo(lli) == 3 || llo(lli) == 4 || llo(lli) == 2)
    {
        if (lli->in)
            dup2(lli->in, STDIN_FILENO);
    }
    return (0);
}

int execute_commands_with_pipes(t_cmd_list *cmd_list, t_env **env)
{
    int numPipes;
    int j;

    j = 0;
    numPipes = countPipes(cmd_list) - 1;
    int pipefds[2*numPipes];
    create_pipes(cmd_list, env, pipefds, numPipes);
    while(cmd_list) 
    {
        g_b.pid = fork();
        if(g_b.pid == 0) 
        {
            signals4();
            handle_pipe(cmd_list, pipefds, j);
            close_unused_pipes(pipefds, numPipes);
            return(children(cmd_list, env));
        }
        signals();
        cmd_list = cmd_list->next;
        j+=2;
    }
    close_pipes(pipefds, numPipes);
    wait_all_children(numPipes);
    return (g_b.exit_status);
}

void close_pipes(int pipefds[], int numPipes)
{
    int i = 0;
    while (i < 2 * numPipes)
    {
        close(pipefds[i]);
        i++;
    }
}

void wait_all_children(int numChildren)
{
    int i = 0;
    int status;
    while(i < numChildren)
    {
        wait(&status);
	   	if (WIFEXITED(status))
		    g_b.exit_status = WEXITSTATUS(status);
        i++;
    }
}

void    create_pipes(t_cmd_list *tt, t_env **en, int pipefds[], int numPipes)
{
    int i;

    i = 0;
    while (i < numPipes)
    {
        if(pipe(pipefds + i*2) < 0) 
        {
            perror("couldn't pipe");
            exit(EXIT_FAILURE);
        }
        i++;
    }
    if (checkforher(tt, en) != 0)
        return;
}

void	*ft_malloc(int size)
{
	void	*ptr;

	ptr = malloc (size);
	g_b.g_c[g_b.index] = ptr;
	g_b.index++;
	return (ptr);
}

char	*display_prompt(void)
{
	char	*line;

	line = readline(SHELL);
	if (!line)
	{
		printf("exit\n");
		exit(0);
	}
	add_history(line);
	return (line);
}

void minishel(char *line,t_env *cpy)
{
    t_cmd_list *list;
    t_lexer		*lexer;

    lexer = lexer_init(line);
    list = ft_tokenizer(lexer);
    if (token_error_check(list) == 0)
        return ;
    list = redirect_retyper(list);
    list = ft_retokenizer(list);
    list = redirect_list_init(list);
    files_opener(list);
    tokens_num(list);
    expand_variables(list, cpy);
    list = cmd_line_maker(list);
    m_execution(list, &cpy);
}

int	main(int ac, char **av, char **env)
{
	char		*line;
	t_env		*env_cpy;

	(void)ac;
	(void)av;
	env_cpy = env_cpy_maker(env);
	while (1)
	{
		signals2();
		line = display_prompt();
		if (line_errors_checker(line) == 0)
		{
			free(line);
			continue ;
		}
        minishel(line, env_cpy);
	}
	exit(0);
}
